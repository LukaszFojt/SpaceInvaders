﻿
using System.Windows.Forms;

namespace MyGame
{
    public class PoleGry : Panel
    {
        public PoleGry()
        {
            this.DoubleBuffered = true;
            this.ResizeRedraw = true;
        }
    }
}
